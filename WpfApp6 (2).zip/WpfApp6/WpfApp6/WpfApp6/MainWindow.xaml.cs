﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp6
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        private ObservableCollection<Thread> _created;
        private ObservableCollection<Thread> _waiting;
        private ObservableCollection<Thread> _working;

        public ObservableCollection<Thread> Working { get { return _working; } set { _working = value; OnPropertyChanged(); } }
        public ObservableCollection<Thread> Waiting { get { return _waiting; } set { _waiting = value; OnPropertyChanged(); } }
        public ObservableCollection<Thread> Created { get { return _created; } set { _created = value; OnPropertyChanged(); } }
        private Semaphore semaphore;

        public MainWindow()
        {
            InitializeComponent();
            Working = new ObservableCollection<Thread>();
            Waiting = new ObservableCollection<Thread>();
            Created = new ObservableCollection<Thread>();
            semaphore = new Semaphore(3, 3, "semaphore");
            DataContext = this;
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Thread thread = new Thread(Method);

            thread.Name = "Thread " + thread.ManagedThreadId;

            Created.Add(thread);
        }

        private void Method(object obj)
        {
            semaphore.WaitOne();
            int id = Convert.ToInt32(obj);
            Application.Current.Dispatcher.Invoke(() =>
            {
                foreach (var item in Created)
                {
                    if (item.ManagedThreadId == id)
                    {
                        Created.Remove(item);
                        Waiting.Add(item);
                        break;
                    }
                }
            });
            Thread.Sleep(5000);
            Application.Current.Dispatcher.Invoke(() =>
            {
                foreach (var item in Waiting)
                {
                    if (item.ManagedThreadId == id)
                    {
                        Waiting.Remove(item);
                        Working.Add(item);
                        break;
                    }
                }
            });
            Thread.Sleep(5000);
            Application.Current.Dispatcher.Invoke(() =>
            {
                foreach (var item in Working)
                {
                    if (item.ManagedThreadId == id)
                    {
                        Working.Remove(item);
                     
                        break;
                    }
                }
            });
            semaphore.Release();
        }

        private void createdList_click(object sender, MouseButtonEventArgs e)
        {
            if (createView.SelectedItem is Thread thread && thread.IsAlive==false)
            {
                thread.Start(thread.ManagedThreadId);
                
            }
            //if (createView.SelectedItem is Thread thread)
            //{
            //    
            //    
            //    
            //    
            //    
            //    
            //    
            //    
            //    
            //}

        }

    }
}
